import { RegisterForm } from 'components/RegisterForm/RegisterForm';

export default function Register() {
  return (
    <div>
      <title>Registration</title>
      <RegisterForm />
    </div>
  );
}
